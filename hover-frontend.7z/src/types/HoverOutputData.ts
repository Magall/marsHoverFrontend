import HoverHistory from "@/types/HoverHistory"
type HoverOutputData = {

    finalPos: HoverHistory;
    hoverHistory: Array<HoverHistory>
}
export default HoverOutputData;
