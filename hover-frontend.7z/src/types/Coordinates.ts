type Cordinates ={
    x:number;
    y:number;
}
export default Cordinates;