type HoverHistory ={
    x:number,
    y:number,
    heading:string
}
export default HoverHistory;