import  Hover  from "./domain/hoverRepository";
export default class Repository{
    hover:Hover
    constructor(){
        this.hover = new Hover();
    }
}