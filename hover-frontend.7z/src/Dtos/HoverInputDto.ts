import  HoverData  from "@/types/HoverData";
import Cordinates from "@/types/Coordinates";
type HoverInputDto  =  {
   hovers:Array<HoverData>
   limit:Cordinates
}
export default HoverInputDto
