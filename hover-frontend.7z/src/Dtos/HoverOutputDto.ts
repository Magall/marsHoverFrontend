import  HoverOutputData from "@/types/HoverOutputData";
 type HoverOutputDto =  {
    hoverOutputData: Array<HoverOutputData>
}
export default HoverOutputDto